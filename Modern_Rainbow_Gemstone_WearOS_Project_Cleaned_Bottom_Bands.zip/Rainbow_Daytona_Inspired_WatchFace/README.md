# Modern Rainbow Gemstone Watch Face

Wear OS Watch Face Format project for Galaxy Watch 5 Pro.

- Black radial sunburst dial
- Rainbow baguette gemstone bezel and matching colored hour markers
- No chronograph subdials
- Live weekday/date, weather temperature, step count, and analog hands

Build and validate through GitHub Actions before installing. This source package has not yet been compiled or passed through the official WFF validator.
