# Rainbow Chronograph — Galaxy Watch 5 Pro

A Wear OS Watch Face Format v2 project with a black sunburst chronograph dial and individually set baguette-cut rainbow gemstones in gold settings. No third-party watch brand logo or name is included.

## Watch-face elements
- Live analog hour, minute, and second hands
- Live weekday and day of month
- Current temperature from the Wear OS weather data source
- Daily step count
- Separate decorative dial artwork and live WFF elements

## Build
This project is intended to be built with Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, and Android SDK Platform 35.

Run `gradle assembleDebug` from this project directory. The APK is created under `app/build/outputs/apk/debug/`.

## Important verification note
The source XML is well-formed, but the WFF v2 schema validator and Android APK build must still be run in GitHub Actions before installing. A successful APK build alone does not confirm that the watch recognizes the app as a selectable watch face.

Weather can be unavailable until the watch receives weather data. Step count and date are live system data sources.
