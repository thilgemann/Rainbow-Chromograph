# Rainbow Chronograph — Wear OS Watch Face project

A custom black-and-gold, rainbow-gemstone-bezel analog watch face designed as a Daytona-inspired look (no Rolex branding). The project uses the Wear OS Watch Face Format (WFF) v2.

## Included
- Analog hour, minute, and seconds hands
- Current temperature from the Wear OS weather data source
- Day of week and day of month
- Daily step count
- Static AMOLED-friendly black dial artwork and rainbow bezel

## Build
1. Install Android Studio (Meerkat or newer) with Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.
6. Install it on the paired Wear OS watch using Android Studio's device selector or `adb install`.

## Set it on the Galaxy Watch 5 Pro
After installing, long-press the current watch face, swipe to **Add watch face**, and select **Rainbow Chronograph**.

## Notes
- This is an Android Studio source project, not a prebuilt/signed APK. It has not been compiled or device-tested in this environment.
- Weather display requires the watch to receive weather data from its paired phone/network and location services; if unavailable, the temperature field may be blank.
- The Watch Face Format renderer and device software determine the exact appearance. Verify alignment on the watch after building.
- If Android Studio reports a WFF XML validation issue, use its Watch Face Format validator and adjust the XML there; the visual assets and project structure are provided.
